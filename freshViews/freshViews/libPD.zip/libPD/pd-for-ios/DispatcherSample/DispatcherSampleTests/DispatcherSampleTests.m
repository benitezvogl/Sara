//
//  DispatcherSampleTests.m
//  DispatcherSampleTests
//
//  Created by Peter Brinkmann on 8/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DispatcherSampleTests.h"


@implementation DispatcherSampleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in DispatcherSampleTests");
}

@end
